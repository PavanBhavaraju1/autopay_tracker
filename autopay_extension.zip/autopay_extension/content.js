// Detect subscription details on the current page.
// For now this is just demo data so you can verify end-to-end flow.
function detectSubscriptionDetails() {
  // TODO: replace with real selectors / parsing
  return {
    service_name: document.title || "Unknown Service",
    amount: 9.99,                     // demo amount
    billing_cycle_days: 30,           // demo monthly
    next_billing_date: new Date().toISOString().slice(0, 10), // today
    status: "upcoming",
    card: {
      name: "Primary Card",
      last4: "4242",
      issuer: "VISA"
    }
  };
}

// Example trigger: run when page finishes loading.
// In a real extension, you might instead hook this up to popup.js or a button.
(function () {
  console.log("AutoPay content script loaded on", window.location.href);

  // Only auto-run on known domains while testing, or guard with a condition
  const payload = detectSubscriptionDetails();

  chrome.runtime.sendMessage(
    { type: "SAVE_AUTOPAY", payload },
    (response) => {
      if (!response) {
        console.log("No response from background");
        return;
      }
      if (response.ok) {
        console.log("Saved to AutoPay Tracker!");
        alert("Saved to AutoPay Tracker dashboard.");
      } else {
        console.log("Failed to save to AutoPay Tracker:", response.step);
        alert("Could not save to AutoPay Tracker. Make sure you are logged in.");
      }
    }
  );
})();
